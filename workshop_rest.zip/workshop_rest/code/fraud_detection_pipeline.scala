// Fraud Detection Pipeline in Spark Scala (Modular + Testable Design)

import org.apache.spark.sql.{SparkSession, DataFrame, functions => F}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types._

object FraudDetection {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName("Fraud Detection - Southeast Asia")
      .master("local[*]")
      .getOrCreate()

    import spark.implicits._

    val users = loadCSV(spark, "users_sea_large.csv")
    val transactions = loadCSV(spark, "transactions_sea_large.csv")
    val logins = loadCSV(spark, "logins_sea_large.csv")
    val fraudSignals = loadCSV(spark, "known_fraud_signals_sea_large.csv")

    val enrichedTxns = transactions.join(users, Seq("user_id"), "left")
    val highValue = detectHighValueTxns(enrichedTxns)
    val burstTxns = detectBurstTransactions(highValue)
    val newLocations = detectNewLocations(burstTxns, users)
    val ringData = detectFraudRing(newLocations, logins)
    val blacklistJoined = detectBlacklisted(logins, fraudSignals, ringData)
    val scored = computeFraudScore(blacklistJoined)

    val alerts = scored.filter(F.col("fraud_score") > 0)
      .select("user_id", "txn_id", "amount", "fraud_score", "ring_id")

    alerts.write.option("header", true).mode("overwrite").csv("fraud_alerts")

    val summary = scored.filter(F.col("fraud_score") > 0)
      .groupBy("user_id")
      .agg(F.max("fraud_score").as("fraud_score"), F.first("ring_id").as("ring_id"))

    summary.write.mode("overwrite").json("fraud_summary")

    spark.stop()
  }

  def loadCSV(spark: SparkSession, path: String): DataFrame = {
    spark.read.option("header", "true").option("inferSchema", "true").csv(s"/mnt/data/$path")
  }

  def detectHighValueTxns(df: DataFrame): DataFrame = {
    df.withColumn("is_high_value_txn", F.when(F.col("amount") > F.col("avg_txn") * 5, 1).otherwise(0))
  }

  def detectBurstTransactions(df: DataFrame): DataFrame = {
    val windowSpec = Window.partitionBy("user_id").orderBy("timestamp").rangeBetween(-300, 0)
    df.withColumn("txn_count_5min", F.count("txn_id").over(windowSpec))
      .withColumn("is_burst_txn", F.when(F.col("txn_count_5min") >= 3, 1).otherwise(0))
  }

  def detectNewLocations(df: DataFrame, users: DataFrame): DataFrame = {
    val knownLocations = users.select("user_id", "branch").withColumnRenamed("branch", "location")
    val newLoc = df.join(knownLocations, Seq("user_id", "location"), "left_anti")
      .withColumn("is_new_location", F.lit(1))
    df.join(newLoc.select("user_id", "location", "is_new_location"), Seq("user_id", "location"), "left")
      .na.fill(0, Seq("is_new_location"))
  }

  def detectFraudRing(df: DataFrame, logins: DataFrame): DataFrame = {
    val deviceUserMap = logins.groupBy("device_id").agg(F.collect_set("user_id").as("linked_users"))
    val ringUsers = deviceUserMap.withColumn("ring_id", F.monotonically_increasing_id())
      .selectExpr("explode(linked_users) as user_id", "ring_id")
    df.join(ringUsers, Seq("user_id"), "left")
      .withColumn("is_in_ring", F.when(F.col("ring_id").isNotNull, 1).otherwise(0))
  }

  def detectBlacklisted(logins: DataFrame, fraudSignals: DataFrame, txns: DataFrame): DataFrame = {
    val flagged = logins.join(fraudSignals, logins("device_id") === fraudSignals("device_id") ||
      logins("ip") === fraudSignals("ip_address"), "left")
      .withColumn("is_blacklisted", F.when(F.col("flag_type").isNotNull, 1).otherwise(0))
      .select("user_id", "is_blacklisted")
      .dropDuplicates("user_id")
    txns.join(flagged, Seq("user_id"), "left").na.fill(0, Seq("is_blacklisted"))
  }

  def computeFraudScore(df: DataFrame): DataFrame = {
    df.withColumn("fraud_score",
      F.col("is_high_value_txn") * 5 +
      F.col("is_burst_txn") * 4 +
      F.col("is_new_location") * 3 +
      F.col("is_in_ring") * 5 +
      F.col("is_blacklisted") * 5)
  }
} 
