import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._
import org.scalatest.funsuite.AnyFunSuite

class FraudDetectionPipelineTest extends AnyFunSuite {

  val spark: SparkSession = SparkSession.builder()
    .appName("FraudDetectionTest")
    .master("local[*]")
    .getOrCreate()

  import spark.implicits._

  test("enrichTransactions should detect high value transactions (positive case)") {
    val users = Seq(("u1", 1000.0)).toDF("user_id", "avg_txn")
    val txns = Seq(("u1", "t1", 6000.0)).toDF("user_id", "txn_id", "amount")
    val result = FraudDetectionPipeline.enrichTransactions(users, txns)
    assert(result.select("is_high_value_txn").as[Int].head == 1)
  }

  test("enrichTransactions should not detect high value transaction (negative case)") {
    val users = Seq(("u1", 1000.0)).toDF("user_id", "avg_txn")
    val txns = Seq(("u1", "t1", 4000.0)).toDF("user_id", "txn_id", "amount")
    val result = FraudDetectionPipeline.enrichTransactions(users, txns)
    assert(result.select("is_high_value_txn").as[Int].head == 0)
  }

  test("detectTransactionBursts should flag 3 txns in 5 minutes (positive case)") {
    val txns = Seq(
      ("u1", "t1", "2024-01-01 10:00:00"),
      ("u1", "t2", "2024-01-01 10:01:00"),
      ("u1", "t3", "2024-01-01 10:03:00")
    ).toDF("user_id", "txn_id", "timestamp")
      .withColumn("timestamp", unix_timestamp(col("timestamp")))

    val result = FraudDetectionPipeline.detectTransactionBursts(txns)
    assert(result.filter("is_burst_txn == 1").count() > 0)
  }

  test("detectTransactionBursts should not flag isolated transactions (negative case)") {
    val txns = Seq(
      ("u2", "t1", "2024-01-01 10:00:00"),
      ("u2", "t2", "2024-01-01 11:01:00"),
      ("u2", "t3", "2024-01-01 12:03:00")
    ).toDF("user_id", "txn_id", "timestamp")
      .withColumn("timestamp", unix_timestamp(col("timestamp")))

    val result = FraudDetectionPipeline.detectTransactionBursts(txns)
    assert(result.filter("is_burst_txn == 1").count() == 0)
  }

  test("detectNewLocation should flag unfamiliar locations (positive case)") {
    val users = Seq(("u1", "Singapore")).toDF("user_id", "branch")
    val txns = Seq(("u1", "Bangkok")).toDF("user_id", "location")
    val result = FraudDetectionPipeline.detectNewLocation(txns, users)
    assert(result.select("is_new_location").as[Int].head == 1)
  }

  test("detectNewLocation should not flag familiar location (negative case)") {
    val users = Seq(("u1", "Singapore")).toDF("user_id", "branch")
    val txns = Seq(("u1", "Singapore")).toDF("user_id", "location")
    val result = FraudDetectionPipeline.detectNewLocation(txns, users)
    assert(result.select("is_new_location").as[Int].head == 0)
  }

  test("detectBlacklistedLogins should flag blacklisted logins (positive case)") {
    val txns = Seq(("u1", "dev1", "ip1")).toDF("user_id", "device_id", "ip")
    val logins = Seq(("u1", "dev1", "ip1")).toDF("user_id", "device_id", "ip")
    val blacklist = Seq(("dev1", "ip1")).toDF("device_id", "ip")
    val result = FraudDetectionPipeline.detectBlacklistedLogins(txns, logins, blacklist)
    assert(result.select("is_blacklisted").as[Int].head == 1)
  }

  test("detectBlacklistedLogins should not flag safe logins (negative case)") {
    val txns = Seq(("u1", "dev1", "ip1")).toDF("user_id", "device_id", "ip")
    val logins = Seq(("u1", "dev1", "ip1")).toDF("user_id", "device_id", "ip")
    val blacklist = Seq(("dev2", "ip2")).toDF("device_id", "ip")
    val result = FraudDetectionPipeline.detectBlacklistedLogins(txns, logins, blacklist)
    assert(result.select("is_blacklisted").as[Int].head == 0)
  }

  test("detectFraudRings should assign ring ID (positive case)") {
    val txns = Seq(("u1"), ("u2")).toDF("user_id")
    val logins = Seq(("dev1", "u1"), ("dev1", "u2")).toDF("device_id", "user_id")
    val result = FraudDetectionPipeline.detectFraudRings(txns, logins)
    val flags = result.select("is_in_ring").distinct().as[Int].collect()
    assert(flags.contains(1))
  }

  test("detectFraudRings should not flag users without shared devices (negative case)") {
    val txns = Seq(("u1"), ("u2")).toDF("user_id")
    val logins = Seq(("dev1", "u1"), ("dev2", "u2")).toDF("device_id", "user_id")
    val result = FraudDetectionPipeline.detectFraudRings(txns, logins)
    val flags = result.select("is_in_ring").distinct().as[Int].collect()
    assert(!flags.contains(1))
  }

  test("calculateFraudScore should sum detection flags") {
    val txns = Seq(("u1", 1, 1, 1, 1, 1)).toDF("user_id", "is_high_value_txn", "is_burst_txn", "is_new_location", "is_blacklisted", "is_in_ring")
    val result = FraudDetectionPipeline.calculateFraudScore(txns)
    assert(result.select("fraud_score").as[Int].head == 22)
  }

  test("calculateFraudScore should be zero when all flags are zero") {
    val txns = Seq(("u1", 0, 0, 0, 0, 0)).toDF("user_id", "is_high_value_txn", "is_burst_txn", "is_new_location", "is_blacklisted", "is_in_ring")
    val result = FraudDetectionPipeline.calculateFraudScore(txns)
    assert(result.select("fraud_score").as[Int].head == 0)
  }
}
