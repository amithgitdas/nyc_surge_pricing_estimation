import org.apache.spark.sql.{DataFrame, SparkSession, functions => F}
import org.apache.spark.sql.expressions.Window

object FraudDetectionPipeline {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName("FraudDetectionPipeline")
      .master("local[*]")
      .getOrCreate()

    import spark.implicits._

    val usersDF = spark.read.option("header", true).option("inferSchema", true).csv("users.csv")
    val transactionsDF = spark.read.option("header", true).option("inferSchema", true).csv("transactions.csv")
    val loginsDF = spark.read.option("header", true).option("inferSchema", true).csv("logins.csv")
    val blacklistDF = spark.read.option("header", true).option("inferSchema", true).csv("known_fraud_signals.csv")

    val enriched = enrichTransactions(usersDF, transactionsDF)
    val withBurst = detectTransactionBursts(enriched)
    val withLocation = detectNewLocation(withBurst, usersDF)
    val withBlacklist = detectBlacklistedLogins(withLocation, loginsDF, blacklistDF)
    val withRings = detectFraudRings(withBlacklist, loginsDF)
    val finalScored = calculateFraudScore(withRings)

    finalScored.filter("fraud_score > 0")
      .coalesce(1)
      .write.mode("overwrite")
      .option("header", true)
      .csv("fraud_alerts")
  }

  def enrichTransactions(users: DataFrame, transactions: DataFrame): DataFrame = {
    transactions.join(users, "user_id")
      .withColumn("is_high_value_txn", F.when(F.col("amount") > F.col("avg_txn") * 5, 1).otherwise(0))
  }

  def detectTransactionBursts(transactions: DataFrame): DataFrame = {
    val windowSpec = Window.partitionBy("user_id").orderBy("timestamp").rangeBetween(-300, 0)
    transactions.withColumn("txn_count_5min",
      F.count("txn_id").over(windowSpec))
      .withColumn("is_burst_txn", F.when(F.col("txn_count_5min") >= 3, 1).otherwise(0))
  }

  def detectNewLocation(transactions: DataFrame, users: DataFrame): DataFrame = {
    transactions.join(users.select("user_id", "branch"), "user_id")
      .withColumn("is_new_location", F.when(F.col("location") =!= F.col("branch"), 1).otherwise(0))
  }

  def detectBlacklistedLogins(transactions: DataFrame, logins: DataFrame, blacklist: DataFrame): DataFrame = {
    val flagged = logins.join(blacklist, Seq("device_id", "ip"), "inner").select("user_id").distinct()
    transactions.join(flagged.withColumn("is_blacklisted", F.lit(1)), Seq("user_id"), "left")
      .na.fill(0, Seq("is_blacklisted"))
  }

  def detectFraudRings(transactions: DataFrame, logins: DataFrame): DataFrame = {
    val deviceSharing = logins.groupBy("device_id").agg(F.collect_set("user_id").as("users"))
    val exploded = deviceSharing.withColumn("user_id", F.explode(F.col("users"))).select("device_id", "user_id")
    val ringMap = exploded.groupBy("user_id").agg(F.hash(F.col("device_id")).as("ring_id"))
    transactions.join(ringMap, Seq("user_id"), "left")
      .withColumn("is_in_ring", F.when(F.col("ring_id").isNotNull, 1).otherwise(0))
  }

  def calculateFraudScore(transactions: DataFrame): DataFrame = {
    transactions.withColumn("fraud_score",
      F.col("is_high_value_txn") * 5 +
        F.col("is_burst_txn") * 4 +
        F.col("is_new_location") * 3 +
        F.col("is_blacklisted") * 5 +
        F.col("is_in_ring") * 5)
  }
} 
