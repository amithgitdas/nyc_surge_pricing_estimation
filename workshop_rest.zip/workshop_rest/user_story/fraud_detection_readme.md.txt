# 🕵️‍♂️ Unmask the Syndicate: Fraud Detection Challenge

## 🔍 Real-Time Fraud Detection in Southeast Asia’s Banking Underground

Welcome to **Apex Intelligence Unit**. You are now an elite data engineer on a mission to uncover a shadowy network siphoning funds from accounts across **Bangkok**, **Jakarta**, **Ho Chi Minh City**, and **Singapore**.

You will leverage Spark Scala and advanced data engineering techniques to analyze millions of records, flag high-risk activity, and reveal the hidden fraud rings.

---

## 🧾 Objective
Build a Spark-based fraud detection pipeline to:
- Detect high-risk transactions
- Score users based on fraud patterns
- Output alerts and summaries for investigators

---

## 📦 Input Datasets

| File | Description |
|------|-------------|
| `users_sea_large.csv` | 25K Apex customers with `avg_txn`, `branch` |
| `transactions_sea_large.csv` | 250K transactions with time, place, amount |
| `logins_sea_large.csv` | 125K login events from devices and countries |
| `known_fraud_signals_sea_large.csv` | 200 flagged devices and IPs from fraud watchlist |

---

## 🧠 Fraud Detection Features

| 🧠 Feature | Description | Output Column | Weight |
|-----------|-------------|----------------|--------|
| **High-Value Transaction** | amount > 5 × avg_txn | `is_high_value_txn` | 5 |
| **Transaction Burst** | ≥ 3 txns in 5 mins | `is_burst_txn` | 4 |
| **New Location** | New city for user | `is_new_location` | 3 |
| **Blacklisted Login** | From known IP/device | `is_blacklisted` | 5 |
| **Fraud Ring** | Shared device/IP with others | `is_in_ring` | 5 |

### 🧮 Fraud Score Formula
```scala
fraud_score =
  is_high_value_txn * 5 +
  is_burst_txn * 4 +
  is_new_location * 3 +
  is_blacklisted * 5 +
  is_in_ring * 5
```

---

## 📤 Output Files

1. **Fraud Alerts (CSV):**
```csv
user_id, txn_id, amount, fraud_score, ring_id
```

2. **Fraud Summary (JSON):**
```json
{
  "user_id": "user_9987",
  "fraud_score": 22,
  "ring_id": 106
}
```

---

## 🛠️ Tasks for Data Engineers

- [ ] Load datasets using Spark Scala
- [ ] Implement each fraud detection feature as a function
- [ ] Join outputs and compute `fraud_score`
- [ ] Write results to CSV & JSON
- [ ] (Optional) Write unit tests for each feature
- [ ] (Optional) Use an AI assistant to generate or refactor code

---

## 🎮 Bonus Challenges

| 🏆 Title | Description |
|---------|-------------|
| 🕵️‍♀️ Top Investigator | Fastest, most accurate pipeline |
| 🤖 Prompt Master | Smartest use of AI assistant |
| 💡 Rule Creator | Propose a new fraud rule |
| ⏱️ Speed Runner | Fastest to submit a working solution |

---

## 🧩 Extra Credit

- Tail the CSV output like a live alerts feed
- Build a heatmap of fraud scores by city
- Add a sixth fraud rule (e.g., login from night hours)

---

## 🧠 Remember:
You're not just writing Spark jobs.
You're uncovering a criminal syndicate.

Good luck, Agent. 💼
